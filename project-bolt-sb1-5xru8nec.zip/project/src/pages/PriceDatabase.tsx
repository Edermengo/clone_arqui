import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton
} from '@mui/material';
import { Search as SearchIcon } from '@mui/icons-material';

export default function PriceDatabase() {
  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Banco de Preços
      </Typography>

      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <TextField
            fullWidth
            label="Pesquisar"
            placeholder="Digite um código ou descrição"
          />
          <Button
            variant="contained"
            startIcon={<SearchIcon />}
          >
            Buscar
          </Button>
        </Box>
      </Paper>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Código</TableCell>
              <TableCell>Descrição</TableCell>
              <TableCell>Unidade</TableCell>
              <TableCell align="right">Preço</TableCell>
              <TableCell>Fonte</TableCell>
              <TableCell>Data Ref.</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            <TableRow>
              <TableCell colSpan={6} align="center">
                <Typography color="textSecondary">
                  Use a busca para encontrar itens
                </Typography>
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
}