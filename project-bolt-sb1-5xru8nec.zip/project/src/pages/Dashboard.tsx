import { Typography, Grid, Paper, Button } from '@mui/material';
import { Add, FolderOpen } from '@mui/icons-material';

export default function Dashboard() {
  return (
    <div>
      <Typography variant="h4" gutterBottom>
        Bem-vindo ao Sistema de Orçamentos
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Button
              variant="contained"
              startIcon={<Add />}
              size="large"
              fullWidth
              sx={{ mb: 2 }}
            >
              Criar Novo Orçamento
            </Button>
            <Button
              variant="outlined"
              startIcon={<FolderOpen />}
              size="large"
              fullWidth
            >
              Abrir Orçamento Existente
            </Button>
          </Paper>
        </Grid>
      </Grid>
    </div>
  );
}