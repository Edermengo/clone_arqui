import { Typography, Box, Paper } from '@mui/material';

export default function Reports() {
  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Relatórios
      </Typography>
      <Paper sx={{ p: 3 }}>
        <Typography>
          Funcionalidade em desenvolvimento
        </Typography>
      </Paper>
    </Box>
  );
}